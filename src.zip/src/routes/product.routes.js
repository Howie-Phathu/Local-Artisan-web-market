const express = require('express');
const router = express.Router();

// TODO: Add product controllers and actual routes
router.get('/', (req, res) => {
  res.json({ message: 'Product routes' });
});

module.exports = router; 