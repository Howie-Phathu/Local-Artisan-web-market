const express = require('express');
const router = express.Router();

// TODO: Add shop controllers and actual routes
router.get('/', (req, res) => {
  res.json({ message: 'Shop routes' });
});

module.exports = router; 