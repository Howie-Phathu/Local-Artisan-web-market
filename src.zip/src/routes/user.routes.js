const express = require('express');
const router = express.Router();

// TODO: Add user controllers and actual routes
router.get('/', (req, res) => {
  res.json({ message: 'User routes' });
});

module.exports = router; 