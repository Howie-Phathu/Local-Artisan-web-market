export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-ZA', {
    style: 'currency',
    currency: 'ZAR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const parseCurrency = (formattedAmount: string): number => {
  // Remove currency symbol and spaces, then parse as float
  return parseFloat(formattedAmount.replace(/[^0-9.-]+/g, ''));
}; 