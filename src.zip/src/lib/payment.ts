// Initialize Yoco with your public key
const YOCO_PUBLIC_KEY = process.env.NEXT_PUBLIC_YOCO_PUBLIC_KEY!;

export interface PaymentResponse {
  id: string;
  amount: number;
  currency: string;
  status: string;
}

export const initializeYoco = () => {
  return new window.YocoSDK({
    publicKey: YOCO_PUBLIC_KEY,
  });
};

export const createPayment = async (amount: number): Promise<PaymentResponse> => {
  try {
    const response = await fetch('/api/create-payment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ amount }),
    });

    if (!response.ok) {
      throw new Error('Failed to create payment');
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating payment:', error);
    throw error;
  }
}; 