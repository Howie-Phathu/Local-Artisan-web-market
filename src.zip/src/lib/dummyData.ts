import { Shop, Product, Category } from './types';

export const dummyCategories: Category[] = [
  { id: 1, name: 'Handmade Jewelry' },
  { id: 2, name: 'Ceramics & Pottery' },
  { id: 3, name: 'Textiles & Fabrics' },
  { id: 4, name: 'Wood Crafts' },
  { id: 5, name: 'Natural Beauty' }
];

export const dummyShops: Shop[] = [
  {
    id: 1,
    name: 'Artisan Creations',
    address: '123 Craft Street, Johannesburg',
    sellerId: 1
  },
  {
    id: 2,
    name: 'Handmade Haven',
    address: '456 Artisan Road, Cape Town',
    sellerId: 2
  },
  {
    id: 3,
    name: 'Local Crafts Co.',
    address: '789 Maker Lane, Durban',
    sellerId: 3
  }
];

export const dummyProducts: Product[] = [
  {
    id: 1,
    name: 'Handcrafted Silver Necklace',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500',
    description: 'Beautiful handcrafted silver necklace with semi-precious stones. Each piece is unique and made with love.',
    price: 1299.99,
    stock: 10,
    categoryId: 1,
    shopId: 1
  },
  {
    id: 2,
    name: 'Ceramic Mug Set',
    image: 'https://images.unsplash.com/photo-1577937927133-537c817a2e7e?w=500',
    description: 'Set of 4 hand-thrown ceramic mugs. Each mug is unique with a beautiful glaze finish.',
    price: 599.99,
    stock: 15,
    categoryId: 2,
    shopId: 1
  },
  {
    id: 3,
    name: 'Handwoven Cotton Scarf',
    image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=500',
    description: 'Soft, handwoven cotton scarf in traditional patterns. Perfect for any season.',
    price: 349.99,
    stock: 20,
    categoryId: 3,
    shopId: 2
  },
  {
    id: 4,
    name: 'Wooden Cutting Board',
    image: 'https://images.unsplash.com/photo-1583241475880-6837b7d4b9bd?w=500',
    description: 'Hand-carved wooden cutting board made from sustainable hardwood. Food-safe finish.',
    price: 449.99,
    stock: 8,
    categoryId: 4,
    shopId: 2
  },
  {
    id: 5,
    name: 'Natural Soap Collection',
    image: 'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=500',
    description: 'Set of 3 handmade natural soaps with essential oils. Gentle on skin and eco-friendly.',
    price: 199.99,
    stock: 25,
    categoryId: 5,
    shopId: 3
  },
  {
    id: 6,
    name: 'Beaded Statement Earrings',
    image: 'https://images.unsplash.com/photo-1630019852942-f89202989a59?w=500',
    description: 'Colorful beaded statement earrings made with glass beads and sterling silver hooks.',
    price: 249.99,
    stock: 12,
    categoryId: 1,
    shopId: 3
  },
  {
    id: 7,
    name: 'Hand-painted Ceramic Vase',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=500',
    description: 'Unique hand-painted ceramic vase with traditional African patterns. Perfect for home decor.',
    price: 799.99,
    stock: 5,
    categoryId: 2,
    shopId: 1
  },
  {
    id: 8,
    name: 'Wool Blanket',
    image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=500',
    description: 'Warm, handwoven wool blanket in traditional patterns. Perfect for cold winter nights.',
    price: 1299.99,
    stock: 7,
    categoryId: 3,
    shopId: 2
  }
];

// Helper function to get products by shop
export const getProductsByShop = (shopId: number): Product[] => {
  return dummyProducts.filter(product => product.shopId === shopId);
};

// Helper function to get products by category
export const getProductsByCategory = (categoryId: number): Product[] => {
  return dummyProducts.filter(product => product.categoryId === categoryId);
};

// Helper function to get a single product
export const getProduct = (id: number): Product | undefined => {
  return dummyProducts.find(product => product.id === id);
};

// Helper function to get a single shop
export const getShop = (id: number): Shop | undefined => {
  return dummyShops.find(shop => shop.id === id);
};

// Helper function to get a single category
export const getCategory = (id: number): Category | undefined => {
  return dummyCategories.find(category => category.id === id);
}; 