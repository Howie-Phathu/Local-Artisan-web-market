// Define the base URL for API requests
// Uses environment variable if available, otherwise defaults to localhost
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api';

// Export the API object containing all API endpoints
export const api = {
  // Users API endpoints
  users: {
    // Get all users
    getAll: async () => {
      const response = await fetch(`${API_URL}/users`);
      if (!response.ok) throw new Error('Failed to fetch users');
      return response.json();
    },
    // Get a specific user by ID
    getById: async (id: string) => {
      const response = await fetch(`${API_URL}/users/${id}`);
      if (!response.ok) throw new Error('Failed to fetch user');
      return response.json();
    },
    // Create a new user
    create: async (data: any) => {
      const response = await fetch(`${API_URL}/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create user');
      return response.json();
    },
    // Update an existing user
    update: async (id: string, data: any) => {
      const response = await fetch(`${API_URL}/users/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update user');
      return response.json();
    },
    // Delete a user
    delete: async (id: string) => {
      const response = await fetch(`${API_URL}/users/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete user');
      return response.json();
    },
  },

  // Shops API endpoints
  shops: {
    // Get all shops
    getAll: async () => {
      const response = await fetch(`${API_URL}/shops`);
      if (!response.ok) throw new Error('Failed to fetch shops');
      return response.json();
    },
    // Get a specific shop by ID
    getById: async (id: string) => {
      const response = await fetch(`${API_URL}/shops/${id}`);
      if (!response.ok) throw new Error('Failed to fetch shop');
      return response.json();
    },
    // Create a new shop
    create: async (data: any) => {
      const response = await fetch(`${API_URL}/shops`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create shop');
      return response.json();
    },
    // Update an existing shop
    update: async (id: string, data: any) => {
      const response = await fetch(`${API_URL}/shops/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update shop');
      return response.json();
    },
    // Delete a shop
    delete: async (id: string) => {
      const response = await fetch(`${API_URL}/shops/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete shop');
      return response.json();
    },
  },

  // Products API endpoints
  products: {
    // Get all products
    getAll: async () => {
      const response = await fetch(`${API_URL}/products`);
      if (!response.ok) throw new Error('Failed to fetch products');
      return response.json();
    },
    // Get products for a specific shop
    getByShop: async (shopId: string) => {
      const response = await fetch(`${API_URL}/products/shop/${shopId}`);
      if (!response.ok) throw new Error('Failed to fetch shop products');
      return response.json();
    },
    // Get a specific product by ID
    getById: async (id: string) => {
      const response = await fetch(`${API_URL}/products/${id}`);
      if (!response.ok) throw new Error('Failed to fetch product');
      return response.json();
    },
    // Create a new product
    create: async (data: any) => {
      const response = await fetch(`${API_URL}/products`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    // Update an existing product
    update: async (id: string, data: any) => {
      const response = await fetch(`${API_URL}/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    // Delete a product
    delete: async (id: string) => {
      const response = await fetch(`${API_URL}/products/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete product');
      return response.json();
    },
  },

  // Cart API endpoints
  cart: {
    // Get the current user's cart
    get: async () => {
      const response = await fetch(`${API_URL}/cart`, {
        headers: {
          'Content-Type': 'application/json',
          // Add auth header if needed
        },
      });
      if (!response.ok) throw new Error('Failed to fetch cart');
      return response.json();
    },
    
    // Add an item to the cart
    addItem: async (data: { productId: string; quantity: number }) => {
      const response = await fetch(`${API_URL}/cart/items`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Add auth header if needed
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to add item to cart');
      }
      return response.json();
    },
    
    // Update the quantity of an item in the cart
    updateItem: async (productId: string, data: { quantity: number }) => {
      const response = await fetch(`${API_URL}/cart/items/${productId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          // Add auth header if needed
        },
        body: JSON.stringify(data),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to update cart item');
      }
      return response.json();
    },
    
    // Remove an item from the cart
    removeItem: async (productId: string) => {
      const response = await fetch(`${API_URL}/cart/items/${productId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          // Add auth header if needed
        },
      });
      if (!response.ok) throw new Error('Failed to remove item from cart');
      return response.json();
    },
    
    // Clear all items from the cart
    clear: async () => {
      const response = await fetch(`${API_URL}/cart/clear`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          // Add auth header if needed
        },
      });
      if (!response.ok) throw new Error('Failed to clear cart');
      return response.json();
    },
  },
}; 