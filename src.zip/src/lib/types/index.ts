export interface Product {
  id: number;
  name: string;
  image: string;
  description: string;
  price: number;
  stock: number;
  categoryId: number;
  shopId: number;
}

export interface Category {
  id: number;
  name: string;
}

export interface Shop {
  id: number;
  name: string;
  address: string;
  sellerId: number;
}

export interface Seller {
  id: number;
  name: string;
  email: string;
  contact: string;
}

export interface Buyer {
  id: number;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface Order {
  id: number;
  orderDate: Date;
  totalPrice: number;
  buyerId: number;
  paymentId: number;
  shipmentId: number;
}

export interface OrderItem {
  id: number;
  orderId: number;
  productId: number;
  quantity: number;
  itemPrice: number;
}

export interface Review {
  id: number;
  buyerId: number;
  productId: number;
  rating: number;
  comment: string;
  reviewDate: Date;
}

export interface Payment {
  id: number;
  orderId: number;
  paymentDate: Date;
  paymentMethod: string;
  amount: number;
}

export interface Shipment {
  id: number;
  shipmentDate: Date;
  address: string;
  carrier: string;
  status: string;
  buyerId: number;
} 