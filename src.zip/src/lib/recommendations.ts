import { api } from './api';

export interface ProductRecommendation {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  similarity: number;
}

export const getRecommendations = async (productId?: string): Promise<ProductRecommendation[]> => {
  try {
    // If a product ID is provided, get recommendations based on that product
    if (productId) {
      const response = await fetch(`/api/recommendations/product/${productId}`);
      if (!response.ok) throw new Error('Failed to fetch recommendations');
      return response.json();
    }

    // Otherwise, get personalized recommendations based on user behavior
    const response = await fetch('/api/recommendations/personalized');
    if (!response.ok) throw new Error('Failed to fetch recommendations');
    return response.json();
  } catch (error) {
    console.error('Error fetching recommendations:', error);
    return [];
  }
};

export const getSimilarProducts = async (productId: string): Promise<ProductRecommendation[]> => {
  try {
    const response = await fetch(`/api/recommendations/similar/${productId}`);
    if (!response.ok) throw new Error('Failed to fetch similar products');
    return response.json();
  } catch (error) {
    console.error('Error fetching similar products:', error);
    return [];
  }
}; 