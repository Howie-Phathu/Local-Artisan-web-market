'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { createPayment, initializeYoco } from '@/lib/payment';

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
  onError: (error: Error) => void;
}

export function PaymentForm({ amount, onSuccess, onError }: PaymentFormProps) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [yoco, setYoco] = useState<any>(null);

  useEffect(() => {
    // Load Yoco SDK script
    const script = document.createElement('script');
    script.src = 'https://js.yoco.com/sdk/v1/yoco-sdk-web.js';
    script.async = true;
    script.onload = () => {
      setYoco(initializeYoco());
    };
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!yoco) {
      return;
    }

    setIsProcessing(true);

    try {
      const payment = await createPayment(amount);

      yoco.showPopup({
        amountInCents: amount * 100,
        currency: 'ZAR',
        name: 'Your Store Name',
        description: 'Payment for your order',
        callback: async (result: any) => {
          if (result.error) {
            onError(new Error(result.error.message));
          } else {
            onSuccess();
          }
          setIsProcessing(false);
        },
      });
    } catch (err) {
      onError(err as Error);
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Button
        type="submit"
        disabled={!yoco || isProcessing}
        className="w-full"
      >
        {isProcessing ? 'Processing...' : `Pay R${amount}`}
      </Button>
    </form>
  );
} 