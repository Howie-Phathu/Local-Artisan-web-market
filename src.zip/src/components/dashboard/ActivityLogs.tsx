'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { activityLogger } from '@/features/auth/services/activityLogger';
import { ActivityLog, ActivityType } from '@/features/auth/types/activity';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';

export default function ActivityLogs() {
  const { user } = useAuth();
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filters, setFilters] = useState({
    activityType: '' as ActivityType | '',
    startDate: '',
    endDate: '',
  });

  useEffect(() => {
    fetchLogs();
  }, [filters]);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await activityLogger.getActivityLogs({
        userId: user?.role === 'admin' ? undefined : user?.id,
        role: user?.role,
        activityType: filters.activityType || undefined,
        startDate: filters.startDate || undefined,
        endDate: filters.endDate || undefined,
      });

      setLogs(response);
    } catch (error) {
      console.error('Error fetching activity logs:', error);
      setError('Failed to load activity logs');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilters({
      activityType: '',
      startDate: '',
      endDate: '',
    });
  };

  if (loading) {
    return <div className="text-center py-8">Loading activity logs...</div>;
  }

  if (error) {
    return <div className="text-center py-8 text-red-600">{error}</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-4 items-end">
        <div>
          <label className="block text-sm font-medium mb-1">Activity Type</label>
          <Select
            value={filters.activityType}
            onValueChange={(value) => handleFilterChange('activityType', value)}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="All Activities" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Activities</SelectItem>
              <SelectItem value="LOGIN">Login</SelectItem>
              <SelectItem value="LOGOUT">Logout</SelectItem>
              <SelectItem value="REGISTER">Register</SelectItem>
              <SelectItem value="UPDATE_PROFILE">Update Profile</SelectItem>
              {user?.role === 'seller' && (
                <>
                  <SelectItem value="ADD_PRODUCT">Add Product</SelectItem>
                  <SelectItem value="UPDATE_PRODUCT">Update Product</SelectItem>
                  <SelectItem value="DELETE_PRODUCT">Delete Product</SelectItem>
                </>
              )}
              {user?.role === 'buyer' && (
                <>
                  <SelectItem value="PLACE_ORDER">Place Order</SelectItem>
                  <SelectItem value="CANCEL_ORDER">Cancel Order</SelectItem>
                </>
              )}
              {user?.role === 'admin' && (
                <>
                  <SelectItem value="MANAGE_USER">Manage User</SelectItem>
                  <SelectItem value="MANAGE_PRODUCT">Manage Product</SelectItem>
                  <SelectItem value="MANAGE_ORDER">Manage Order</SelectItem>
                </>
              )}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Start Date</label>
          <Input
            type="date"
            value={filters.startDate}
            onChange={(e) => handleFilterChange('startDate', e.target.value)}
            className="w-[200px]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">End Date</label>
          <Input
            type="date"
            value={filters.endDate}
            onChange={(e) => handleFilterChange('endDate', e.target.value)}
            className="w-[200px]"
          />
        </div>

        <Button variant="outline" onClick={clearFilters}>
          Clear Filters
        </Button>
      </div>

      <div className="border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Timestamp</TableHead>
              <TableHead>Activity</TableHead>
              <TableHead>Description</TableHead>
              {user?.role === 'admin' && <TableHead>User</TableHead>}
              <TableHead>IP Address</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs.map((log) => (
              <TableRow key={log.id}>
                <TableCell>
                  {format(new Date(log.timestamp), 'PPpp')}
                </TableCell>
                <TableCell>{log.activityType}</TableCell>
                <TableCell>{log.description}</TableCell>
                {user?.role === 'admin' && (
                  <TableCell>
                    {log.userId} ({log.userRole})
                  </TableCell>
                )}
                <TableCell>{log.ipAddress || 'N/A'}</TableCell>
              </TableRow>
            ))}
            {logs.length === 0 && (
              <TableRow>
                <TableCell colSpan={user?.role === 'admin' ? 5 : 4} className="text-center py-8">
                  No activity logs found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
} 