'use client';

import { useState, useEffect } from 'react';
import { getRecommendations, getSimilarProducts, ProductRecommendation } from '@/lib/recommendations';
import ProductCard from './ProductCard';
import { Skeleton } from '@/components/ui/skeleton';

interface ProductRecommendationsProps {
  productId?: string;
  title?: string;
  limit?: number;
}

export function ProductRecommendations({ 
  productId, 
  title = 'Recommended for You', 
  limit = 4 
}: ProductRecommendationsProps) {
  const [recommendations, setRecommendations] = useState<ProductRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchRecommendations = async () => {
      try {
        setLoading(true);
        setError(null);

        let data: ProductRecommendation[];
        if (productId) {
          data = await getSimilarProducts(productId);
        } else {
          data = await getRecommendations();
        }

        // Sort by similarity and limit the number of recommendations
        data.sort((a, b) => b.similarity - a.similarity);
        setRecommendations(data.slice(0, limit));
      } catch (err) {
        console.error('Error fetching recommendations:', err);
        setError('Failed to load recommendations');
      } finally {
        setLoading(false);
      }
    };

    fetchRecommendations();
  }, [productId, limit]);

  if (loading) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">{title}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(limit)].map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <Skeleton className="aspect-w-3 aspect-h-2" />
              <div className="p-4 space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-8 w-1/4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error || recommendations.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">{title}</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {recommendations.map((product) => (
          <ProductCard
            key={product.id}
            product={{
              id: product.id,
              name: product.name,
              description: product.description,
              price: product.price,
              image: product.image,
              images: [product.image],
              category: '',
              categoryId: '',
              stock: 0,
              shopId: '',
              createdAt: '',
              shop: {
                id: '',
                name: '',
              },
            }}
            showShop={false}
          />
        ))}
      </div>
    </div>
  );
} 