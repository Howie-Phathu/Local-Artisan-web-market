'use client';

import { useProducts } from '@/features/products/hooks/useProducts';
import { useState } from 'react';
import type { ProductFilters } from '@/features/products/types';
import ProductCard from './ProductCard';
import ProductFilters from './ProductFilters';

const defaultFilters: ProductFilters = {
  categoryId: null,
  priceRange: [0, 1000],
  sortBy: 'newest'
};

export default function ProductList() {
  const [filters, setFilters] = useState<ProductFilters>(defaultFilters);
  const { products, categories, loading, error } = useProducts();

  const handleFilterChange = (newFilters: Partial<ProductFilters>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  const handleResetFilters = () => {
    setFilters(defaultFilters);
  };

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">{error}</p>
        <button
          onClick={handleResetFilters}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <ProductFilters
            categories={categories || []}
            currentFilters={filters}
            onFilterChange={handleFilterChange}
            onReset={handleResetFilters}
          />
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">
              Products ({products.length})
            </h2>
            {loading && (
              <div className="text-sm text-gray-500">Loading...</div>
            )}
          </div>

          {products.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No products found matching your criteria.</p>
              <button
                onClick={handleResetFilters}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  showShop={true}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 