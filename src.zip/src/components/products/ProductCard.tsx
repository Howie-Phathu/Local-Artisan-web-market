import Link from 'next/link';
import { ShoppingCart } from 'lucide-react';
import type { Product } from '@/types/product';
import { formatCurrency } from '@/lib/utils/currency';

// Props interface for the ProductCard component
interface ProductCardProps {
  // The product data to display
  product: Product & {
    // Optional shop information
    shop?: {
      name: string;
    };
  };
  // Whether to show the shop name
  showShop?: boolean;
}

// ProductCard component for displaying a single product
export default function ProductCard({ product, showShop = true }: ProductCardProps) {
  return (
    // Main container with white background and shadow
    <div className="bg-white rounded-lg shadow-md overflow-hidden group">
      {/* Link to product details page */}
      <Link href={`/products/${product.id}`} className="block relative">
        {/* Product image container with aspect ratio */}
        <div className="aspect-w-3 aspect-h-2">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
          />
        </div>
        {/* Add to cart button that appears on hover */}
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            className="bg-white p-2 rounded-full shadow-lg hover:bg-gray-100"
            onClick={(e) => {
              e.preventDefault();
              // Add to cart functionality will be implemented later
            }}
          >
            <ShoppingCart className="h-5 w-5 text-gray-600" />
          </button>
        </div>
      </Link>
      
      {/* Product information container */}
      <div className="p-4">
        {/* Product name link */}
        <Link href={`/products/${product.id}`} className="block">
          <h3 className="text-lg font-semibold mb-1 hover:text-indigo-600">
            {product.name}
          </h3>
        </Link>
        
        {/* Shop name link (if showShop is true and shop exists) */}
        {showShop && product.shop && (
          <Link href={`/shops/${product.shopId}`} className="block">
            <p className="text-sm text-gray-600 mb-2 hover:text-indigo-600">
              {product.shop.name}
            </p>
          </Link>
        )}
        
        {/* Price and stock information */}
        <div className="flex items-center justify-between">
          {/* Formatted price using ZAR currency */}
          <span className="text-xl font-bold">{formatCurrency(product.price)}</span>
          {/* Stock status indicator */}
          {product.stock > 0 ? (
            <span className="text-sm text-green-600">In Stock</span>
          ) : (
            <span className="text-sm text-red-600">Out of Stock</span>
          )}
        </div>
      </div>
    </div>
  );
} 