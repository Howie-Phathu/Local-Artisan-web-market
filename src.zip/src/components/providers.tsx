'use client';

import { AuthProvider } from '@/features/auth/hooks/useAuth';
import { CartProvider } from '@/features/cart/context/CartContext';
import { Suspense } from 'react';

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <AuthProvider>
        <CartProvider>
          {children}
        </CartProvider>
      </AuthProvider>
    </Suspense>
  );
} 