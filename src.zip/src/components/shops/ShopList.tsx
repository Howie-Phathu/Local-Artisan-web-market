'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import type { Shop } from '@/types/shop';

export default function ShopList() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchShops();
  }, []);

  const fetchShops = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.shops.getAll();
      setShops(response.data || []);
    } catch (error) {
      console.error('Error fetching shops:', error);
      setError('Failed to fetch shops. Please try again later.');
      setShops([]);
    } finally {
      setLoading(false);
    }
  };

  if (error) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">{error}</p>
        <button
          onClick={fetchShops}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Artisan Shops ({shops.length})</h2>
        {loading && <div className="text-sm text-gray-500">Loading...</div>}
      </div>

      {shops.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No shops found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {shops.map(shop => (
            <div
              key={shop.id}
              className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{shop.name}</h3>
                <p className="text-gray-600 mb-4">{shop.description}</p>
                <div className="flex items-center text-sm text-gray-500">
                  <span className="mr-4">
                    <i className="fas fa-map-marker-alt mr-1"></i>
                    {shop.location}
                  </span>
                  <span>
                    <i className="fas fa-star mr-1"></i>
                    {shop.rating || 'New'}
                  </span>
                </div>
                <a
                  href={`/shops/${shop.id}`}
                  className="mt-4 inline-block px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
                >
                  View Shop
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
} 