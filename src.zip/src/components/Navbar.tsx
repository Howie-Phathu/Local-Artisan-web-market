'use client';

import { Button } from '@/components/ui/button';
import { ShoppingCart, LogIn } from 'lucide-react';
import Link from 'next/link';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useCart } from '@/features/cart/hooks/useCart';

export default function Navbar() {
  const { items } = useCart();

  return (
    <nav className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="text-xl font-bold">
            Artisan Marketplace
          </Link>

          <div className="flex items-center gap-4">
            <Link href="/shops">
              <Button variant="ghost">Shops</Button>
            </Link>
            <Link href="/products">
              <Button variant="ghost">Products</Button>
            </Link>

            <Link href="/cart" className="relative">
              <Button variant="ghost" size="icon">
                <ShoppingCart className="h-5 w-5" />
                {items.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {items.length}
                  </span>
                )}
              </Button>
            </Link>

            <Link href="/auth">
              <Button variant="ghost">
                <LogIn className="h-5 w-5 mr-2" />
                Login
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
} 