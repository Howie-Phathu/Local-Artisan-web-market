'use client';

import { useState } from 'react';
import { Button } from './button';
import { X, Upload } from 'lucide-react';
import Image from 'next/image';

interface ImageUploadProps {
  value: string;
  onChange: (value: string) => void;
  onRemove?: () => void;
  aspectRatio?: number;
}

export function ImageUpload({
  value,
  onChange,
  onRemove,
  aspectRatio = 1,
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      // TODO: Implement actual file upload to your storage service
      // For now, we'll use a mock URL
      const mockUrl = URL.createObjectURL(file);
      onChange(mockUrl);
    } catch (error) {
      console.error('Error uploading image:', error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="relative">
      {value ? (
        <div className="relative aspect-square w-full overflow-hidden rounded-lg">
          <Image
            src={value}
            alt="Uploaded image"
            fill
            className="object-cover"
          />
          {onRemove && (
            <Button
              type="button"
              variant="destructive"
              size="icon"
              className="absolute top-2 right-2"
              onClick={onRemove}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      ) : (
        <div
          className="relative flex aspect-square w-full cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-gray-300 bg-gray-50 hover:bg-gray-100"
          style={{ aspectRatio }}
        >
          <input
            type="file"
            accept="image/*"
            className="absolute inset-0 cursor-pointer opacity-0"
            onChange={handleFileChange}
            disabled={isUploading}
          />
          <Upload className="h-8 w-8 text-gray-400" />
          <p className="mt-2 text-sm text-gray-500">
            {isUploading ? 'Uploading...' : 'Click to upload image'}
          </p>
        </div>
      )}
    </div>
  );
} 