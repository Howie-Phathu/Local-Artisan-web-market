'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';

interface Shop {
  id: string;
  name: string;
  description: string;
  logo: string;
  banner: string;
  userId: string;
  products?: Product[];
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  images: string[];
  totalSales: number;
}

export function useShops() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchShops = async () => {
      try {
        const data = await api.shops.getAll();
        setShops(data);
      } catch (error) {
        console.error('Error fetching shops:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchShops();
  }, []);

  const getShop = (id: string) => {
    return shops.find((shop) => shop.id === id);
  };

  const createShop = async (data: Omit<Shop, 'id'>) => {
    try {
      const newShop = await api.shops.create(data);
      setShops((prev) => [...prev, newShop]);
      return newShop;
    } catch (error) {
      console.error('Error creating shop:', error);
      throw error;
    }
  };

  const updateShop = async (id: string, data: Partial<Shop>) => {
    try {
      const updatedShop = await api.shops.update(id, data);
      setShops((prev) =>
        prev.map((shop) => (shop.id === id ? updatedShop : shop))
      );
    } catch (error) {
      console.error('Error updating shop:', error);
      throw error;
    }
  };

  const deleteShop = async (id: string) => {
    try {
      await api.shops.delete(id);
      setShops((prev) => prev.filter((shop) => shop.id !== id));
    } catch (error) {
      console.error('Error deleting shop:', error);
      throw error;
    }
  };

  return {
    shops,
    loading,
    getShop,
    createShop,
    updateShop,
    deleteShop,
  };
} 