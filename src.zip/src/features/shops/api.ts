import type { Shop, CreateShopData, UpdateShopData } from '@/types/shop';

// Mock data for development
const mockShops = [
  {
    id: '1',
    name: 'Handcrafted Creations',
    description: 'Beautiful handmade jewelry and accessories crafted with love and attention to detail.',
    logo: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8amV3ZWxyeSUyMHNob3B8ZW58MHx8MHx8fDA%3D',
    banner: 'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8amV3ZWxyeSUyMHNob3B8ZW58MHx8MHx8fDA%3D',
    rating: 4.8,
    totalSales: 124,
  },
  {
    id: '2',
    name: 'Artisan Pottery',
    description: 'Unique ceramic pieces and pottery made using traditional techniques.',
    logo: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cG90dGVyeSUyMHNob3B8ZW58MHx8MHx8fDA%3D',
    banner: 'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8cG90dGVyeSUyMHNob3B8ZW58MHx8MHx8fDA%3D',
    rating: 4.9,
    totalSales: 89,
  },
  {
    id: '3',
    name: 'Wooden Wonders',
    description: 'Handcrafted wooden furniture and home decor items made from sustainable materials.',
    logo: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8d29vZGVuJTIwZnVybml0dXJlfGVufDB8fDB8fHww',
    banner: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8d29vZGVuJTIwZnVybml0dXJlfGVufDB8fDB8fHww',
    rating: 4.7,
    totalSales: 156,
  },
];

export async function getShops() {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockShops;
}

export async function getShop(id: string) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockShops.find((shop) => shop.id === id);
}

export async function createShop(data: CreateShopData): Promise<Shop> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const newShop: Shop = {
    id: mockShops.length + 1,
    name: data.name,
    description: data.description,
    logo: data.logo ? URL.createObjectURL(data.logo) : "/images/shops/default-logo.jpg",
    banner: data.banner ? URL.createObjectURL(data.banner) : "/images/shops/default-banner.jpg",
    ownerId: 1, // This would come from the authenticated user
    rating: 0,
    totalSales: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  mockShops.push(newShop);
  return newShop;
}

export async function updateShop(id: number, data: UpdateShopData): Promise<Shop> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const shopIndex = mockShops.findIndex(shop => shop.id === id);
  if (shopIndex === -1) {
    throw new Error("Shop not found");
  }

  const updatedShop = {
    ...mockShops[shopIndex],
    ...data,
    updatedAt: new Date().toISOString(),
  };

  mockShops[shopIndex] = updatedShop;
  return updatedShop;
}

export async function deleteShop(id: number): Promise<void> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const shopIndex = mockShops.findIndex(shop => shop.id === id);
  if (shopIndex === -1) {
    throw new Error("Shop not found");
  }

  mockShops.splice(shopIndex, 1);
} 