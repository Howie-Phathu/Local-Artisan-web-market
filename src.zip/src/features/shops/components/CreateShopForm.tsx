'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useShops } from '../hooks/useShops';
import { useRouter } from 'next/navigation';
import { ImageUpload } from '@/components/ui/image-upload';
import { motion } from 'framer-motion';

const shopSchema = z.object({
  name: z.string().min(3, 'Name must be at least 3 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  logo: z.instanceof(File).optional(),
  banner: z.instanceof(File).optional(),
});

type ShopFormData = z.infer<typeof shopSchema>;

export function CreateShopForm() {
  const { addShop } = useShops();
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm<ShopFormData>({
    resolver: zodResolver(shopSchema),
  });

  const logoFile = watch('logo');
  const bannerFile = watch('banner');

  const onSubmit = async (data: ShopFormData) => {
    try {
      setIsSubmitting(true);
      await addShop(data);
      router.push('/dashboard/shops');
    } catch (error) {
      console.error('Error creating shop:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto p-6"
    >
      <h1 className="text-2xl font-bold mb-6">Create Your Shop</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Shop Name</label>
          <Input
            {...register('name')}
            placeholder="Enter your shop name"
            className={errors.name ? 'border-red-500' : ''}
          />
          {errors.name && (
            <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Description</label>
          <Textarea
            {...register('description')}
            placeholder="Tell us about your shop"
            className={errors.description ? 'border-red-500' : ''}
            rows={4}
          />
          {errors.description && (
            <p className="text-red-500 text-sm mt-1">
              {errors.description.message}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Shop Logo</label>
          <ImageUpload
            value={logoFile ? URL.createObjectURL(logoFile) : ''}
            onChange={(file) => setValue('logo', file)}
            className="w-32 h-32"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Shop Banner</label>
          <ImageUpload
            value={bannerFile ? URL.createObjectURL(bannerFile) : ''}
            onChange={(file) => setValue('banner', file)}
            className="w-full h-48"
          />
        </div>

        <Button
          type="submit"
          className="w-full"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Creating...' : 'Create Shop'}
        </Button>
      </form>
    </motion.div>
  );
} 