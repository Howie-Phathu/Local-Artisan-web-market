import { ActivityLog, ActivityType } from '../types/activity';
import { api } from '@/lib/api';

class ActivityLogger {
  private static instance: ActivityLogger;
  private queue: ActivityLog[] = [];
  private isProcessing = false;

  private constructor() {
    // Initialize any necessary setup
  }

  public static getInstance(): ActivityLogger {
    if (!ActivityLogger.instance) {
      ActivityLogger.instance = new ActivityLogger();
    }
    return ActivityLogger.instance;
  }

  public async logActivity(
    userId: string,
    userRole: 'buyer' | 'seller' | 'admin',
    activityType: ActivityType,
    description: string,
    metadata?: Record<string, any>
  ): Promise<void> {
    const activity: ActivityLog = {
      id: crypto.randomUUID(),
      userId,
      userRole,
      activityType,
      description,
      metadata,
      timestamp: new Date().toISOString(),
      ipAddress: await this.getIpAddress(),
      userAgent: typeof window !== 'undefined' ? window.navigator.userAgent : undefined,
    };

    // Add to queue
    this.queue.push(activity);

    // Process queue if not already processing
    if (!this.isProcessing) {
      await this.processQueue();
    }
  }

  private async processQueue(): Promise<void> {
    if (this.isProcessing || this.queue.length === 0) return;

    this.isProcessing = true;

    try {
      while (this.queue.length > 0) {
        const activity = this.queue[0];
        try {
          await api.activity.log(activity);
          this.queue.shift(); // Remove processed activity
        } catch (error) {
          console.error('Failed to log activity:', error);
          // Keep the activity in queue for retry
          break;
        }
      }
    } finally {
      this.isProcessing = false;
    }
  }

  private async getIpAddress(): Promise<string | undefined> {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip;
    } catch (error) {
      console.error('Failed to get IP address:', error);
      return undefined;
    }
  }

  public async getActivityLogs(filters: {
    userId?: string;
    role?: 'buyer' | 'seller' | 'admin';
    activityType?: ActivityType;
    startDate?: string;
    endDate?: string;
  }): Promise<ActivityLog[]> {
    try {
      const response = await api.activity.getLogs(filters);
      return response.data;
    } catch (error) {
      console.error('Failed to fetch activity logs:', error);
      throw error;
    }
  }
}

export const activityLogger = ActivityLogger.getInstance(); 