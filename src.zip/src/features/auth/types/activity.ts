export type ActivityType = 
  | 'LOGIN'
  | 'LOGOUT'
  | 'REGISTER'
  | 'UPDATE_PROFILE'
  | 'ADD_PRODUCT'  // for sellers
  | 'UPDATE_PRODUCT'  // for sellers
  | 'DELETE_PRODUCT'  // for sellers
  | 'PLACE_ORDER'  // for buyers
  | 'CANCEL_ORDER'  // for buyers
  | 'MANAGE_USER'  // for admins
  | 'MANAGE_PRODUCT'  // for admins
  | 'MANAGE_ORDER'  // for admins;

export interface ActivityLog {
  id: string;
  userId: string;
  userRole: 'buyer' | 'seller' | 'admin';
  activityType: ActivityType;
  description: string;
  metadata?: Record<string, any>;
  timestamp: string;
  ipAddress?: string;
  userAgent?: string;
}

export interface ActivityFilters {
  userId?: string;
  role?: 'buyer' | 'seller' | 'admin';
  activityType?: ActivityType;
  startDate?: string;
  endDate?: string;
} 