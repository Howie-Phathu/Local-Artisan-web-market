'use client';

import { useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  isAdmin: boolean;
  isSeller: boolean;
  isActive: boolean;
}

export function useUsers() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // TODO: Replace with actual API call
    // Mock data for development
    const mockUsers: User[] = [
      {
        id: '1',
        name: 'Admin User',
        email: 'admin@example.com',
        isAdmin: true,
        isSeller: false,
        isActive: true,
      },
      {
        id: '2',
        name: 'Seller User',
        email: 'seller@example.com',
        isAdmin: false,
        isSeller: true,
        isActive: true,
      },
      {
        id: '3',
        name: 'Customer User',
        email: 'customer@example.com',
        isAdmin: false,
        isSeller: false,
        isActive: true,
      },
    ];
    setUsers(mockUsers);
    setLoading(false);
  }, []);

  const getUser = (id: string) => {
    return users.find((user) => user.id === id);
  };

  const createUser = async (data: Omit<User, 'id'>) => {
    // TODO: Replace with actual API call
    const newUser = {
      id: String(users.length + 1),
      ...data,
    };
    setUsers((prev) => [...prev, newUser]);
    return newUser;
  };

  const updateUser = async (id: string, data: Partial<User>) => {
    // TODO: Replace with actual API call
    setUsers((prev) =>
      prev.map((user) => (user.id === id ? { ...user, ...data } : user))
    );
  };

  const deleteUser = async (id: string) => {
    // TODO: Replace with actual API call
    setUsers((prev) => prev.filter((user) => user.id !== id));
  };

  return {
    users,
    loading,
    getUser,
    createUser,
    updateUser,
    deleteUser,
  };
} 