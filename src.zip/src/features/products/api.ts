import type { Product, Category } from '@/types/product';
import type { ProductWithDetails, ProductFilters, ProductListResponse } from './types';

// This would normally make API calls to a backend server
// For now, we'll use mock data

const mockProducts: ProductWithDetails[] = [
  {
    id: 1,
    name: 'Handcrafted Leather Bag',
    price: 199.99,
    image: '/images/products/bag.jpg',
    description: 'Beautiful handcrafted leather bag made with genuine Italian leather. Perfect for everyday use or special occasions.',
    stock: 5,
    categoryId: 1,
    shopId: 1,
    shop: {
      name: 'Leather Artisans Co.',
      rating: 4.8,
      totalSales: 1234,
    },
  },
  // Add more mock products...
];

const mockCategories: Category[] = [
  { id: 1, name: 'Bags & Accessories' },
  { id: 2, name: 'Home & Living' },
  { id: 3, name: 'Jewelry' },
  { id: 4, name: 'Art' },
];

export async function getProducts(filters: ProductFilters): Promise<ProductListResponse> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));

  let filteredProducts = [...mockProducts];

  // Apply filters
  if (filters.categoryId) {
    filteredProducts = filteredProducts.filter(p => p.categoryId === filters.categoryId);
  }

  filteredProducts = filteredProducts.filter(p => 
    p.price >= filters.priceRange[0] && p.price <= filters.priceRange[1]
  );

  // Apply sorting
  filteredProducts.sort((a, b) => {
    switch (filters.sortBy) {
      case 'price_asc':
        return a.price - b.price;
      case 'price_desc':
        return b.price - a.price;
      case 'newest':
        return b.id - a.id;
      default:
        return 0;
    }
  });

  return {
    products: filteredProducts,
    total: filteredProducts.length,
    page: 1,
    totalPages: 1,
  };
}

export async function getProduct(id: number): Promise<ProductWithDetails | null> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockProducts.find(p => p.id === id) || null;
}

export async function getCategories(): Promise<Category[]> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockCategories;
}

export async function getFeaturedProducts(): Promise<Product[]> {
  await new Promise(resolve => setTimeout(resolve, 500));
  return mockProducts.slice(0, 3);
} 