import type { Product, Category, Review } from '@/types/product';

export interface ProductWithDetails extends Product {
  shop?: {
    name: string;
    rating: number;
    totalSales: number;
  };
  reviews?: Review[];
}

export interface ProductFilters {
  categoryId?: number | null;
  priceRange: [number, number];
  sortBy: 'price_asc' | 'price_desc' | 'newest';
}

export interface ProductListResponse {
  products: Product[];
  total: number;
  page: number;
  totalPages: number;
} 