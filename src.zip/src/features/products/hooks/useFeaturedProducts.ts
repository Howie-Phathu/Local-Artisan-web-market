import { useState, useEffect } from 'react';
import { getFeaturedProducts, getCategories } from '../api';
import type { Product, Category } from '@/types/product';

export function useFeaturedProducts() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadFeaturedProducts();
    loadCategories();
  }, []);

  async function loadFeaturedProducts() {
    try {
      setLoading(true);
      setError(null);
      const products = await getFeaturedProducts();
      setFeaturedProducts(products);
    } catch (err) {
      setError('Failed to load featured products');
      console.error('Error loading featured products:', err);
    } finally {
      setLoading(false);
    }
  }

  async function loadCategories() {
    try {
      const fetchedCategories = await getCategories();
      setCategories(fetchedCategories);
    } catch (err) {
      console.error('Error loading categories:', err);
    }
  }

  return {
    featuredProducts,
    categories,
    loading,
    error,
  };
} 