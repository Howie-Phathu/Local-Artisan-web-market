import { useState, useEffect } from 'react';
import { getProduct } from '../api';
import type { ProductWithDetails } from '../types';

export function useProductDetails(productId: number) {
  const [product, setProduct] = useState<ProductWithDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadProduct();
  }, [productId]);

  async function loadProduct() {
    try {
      setLoading(true);
      setError(null);
      const productData = await getProduct(productId);
      setProduct(productData);
    } catch (err) {
      setError('Failed to load product details');
      console.error('Error loading product:', err);
    } finally {
      setLoading(false);
    }
  }

  return {
    product,
    loading,
    error,
  };
} 