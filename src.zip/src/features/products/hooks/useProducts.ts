'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import type { Product, Category } from '@/types/product';

// Custom hook for managing products
export function useProducts(shopId?: string) {
  // State for storing products
  const [products, setProducts] = useState<Product[]>([]);
  // State for storing categories
  const [categories, setCategories] = useState<Category[]>([]);
  // State for loading status
  const [loading, setLoading] = useState(true);
  // State for error handling
  const [error, setError] = useState<string | null>(null);

  // Effect to fetch products when component mounts or shopId changes
  useEffect(() => {
    fetchProducts();
  }, [shopId]);

  // Function to fetch products from the API
  const fetchProducts = async () => {
    try {
      // Set loading state to true
      setLoading(true);
      // Clear any previous errors
      setError(null);
      
      let response;
      // If shopId is provided, fetch products for that shop
      if (shopId) {
        response = await api.products.getByShop(shopId);
      } else {
        // Otherwise fetch all products
        response = await api.products.getAll();
      }
      
      // Update products state with the fetched data
      setProducts(response.data || []);
    } catch (error) {
      // Handle any errors that occur during fetching
      console.error('Error fetching products:', error);
      setError('Failed to fetch products. Please try again later.');
      setProducts([]);
    } finally {
      // Set loading state to false regardless of success or failure
      setLoading(false);
    }
  };

  // Function to create a new product
  const createProduct = async (productData: Omit<Product, 'id'>) => {
    try {
      // Call the API to create a new product
      const response = await api.products.create({
        ...productData,
        shopId: shopId ? parseInt(shopId, 10) : undefined
      });
      // Add the new product to the existing products list
      setProducts(prev => [...prev, response.data]);
      return response.data;
    } catch (error) {
      // Handle any errors that occur during creation
      console.error('Error creating product:', error);
      throw new Error('Failed to create product. Please try again later.');
    }
  };

  // Function to update an existing product
  const updateProduct = async (id: string, productData: Partial<Product>) => {
    try {
      // Call the API to update the product
      const response = await api.products.update(id, {
        ...productData,
        shopId: shopId ? parseInt(shopId, 10) : undefined
      });
      // Update the product in the existing products list
      setProducts(prev => prev.map(product => 
        product.id === parseInt(id, 10) ? response.data : product
      ));
      return response.data;
    } catch (error) {
      // Handle any errors that occur during update
      console.error('Error updating product:', error);
      throw new Error('Failed to update product. Please try again later.');
    }
  };

  // Function to delete a product
  const deleteProduct = async (id: string) => {
    try {
      // Call the API to delete the product
      await api.products.delete(id);
      // Remove the product from the existing products list
      setProducts(prev => prev.filter(product => product.id !== parseInt(id, 10)));
    } catch (error) {
      // Handle any errors that occur during deletion
      console.error('Error deleting product:', error);
      throw new Error('Failed to delete product. Please try again later.');
    }
  };

  // Return the products data and functions for managing products
  return {
    products,
    categories,
    loading,
    error,
    createProduct,
    updateProduct,
    deleteProduct,
    refresh: fetchProducts
  };
} 