'use client';

import { createContext, useContext, useState, useEffect } from 'react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import type { Product } from '@/types/product';

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartContextType {
  items: CartItem[];
  addItem: (product: Product, quantity: number) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  clearCart: () => Promise<void>;
  loading: boolean;
  error: string | null;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load cart on mount
  useEffect(() => {
    fetchCart();
  }, []);

  // Fetch cart from API
  const fetchCart = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.cart.get();
      setItems(response.data.items || []);
    } catch (error) {
      console.error('Error fetching cart:', error);
      setError('Failed to load cart');
    } finally {
      setLoading(false);
    }
  };

  // Add item to cart
  const addItem = async (product: Product, quantity: number) => {
    try {
      setLoading(true);
      setError(null);

      // Check if item already exists in cart
      const existingItem = items.find(item => item.product.id === product.id);
      if (existingItem) {
        // Update quantity if item exists
        await updateQuantity(product.id, existingItem.quantity + quantity);
      } else {
        // Add new item
        await api.cart.addItem({
          productId: product.id,
          quantity,
        });
        setItems(prev => [...prev, { product, quantity }]);
        toast.success('Item added to cart');
      }
    } catch (error) {
      console.error('Error adding item to cart:', error);
      setError('Failed to add item to cart');
      toast.error('Failed to add item to cart');
    } finally {
      setLoading(false);
    }
  };

  // Update item quantity
  const updateQuantity = async (productId: string, quantity: number) => {
    try {
      setLoading(true);
      setError(null);

      if (quantity <= 0) {
        await removeItem(productId);
        return;
      }

      await api.cart.updateItem(productId, { quantity });
      setItems(prev =>
        prev.map(item =>
          item.product.id === productId
            ? { ...item, quantity }
            : item
        )
      );
      toast.success('Cart updated');
    } catch (error) {
      console.error('Error updating cart:', error);
      setError('Failed to update cart');
      toast.error('Failed to update cart');
    } finally {
      setLoading(false);
    }
  };

  // Remove item from cart
  const removeItem = async (productId: string) => {
    try {
      setLoading(true);
      setError(null);

      await api.cart.removeItem(productId);
      setItems(prev => prev.filter(item => item.product.id !== productId));
      toast.success('Item removed from cart');
    } catch (error) {
      console.error('Error removing item from cart:', error);
      setError('Failed to remove item from cart');
      toast.error('Failed to remove item from cart');
    } finally {
      setLoading(false);
    }
  };

  // Clear cart
  const clearCart = async () => {
    try {
      setLoading(true);
      setError(null);

      await api.cart.clear();
      setItems([]);
      toast.success('Cart cleared');
    } catch (error) {
      console.error('Error clearing cart:', error);
      setError('Failed to clear cart');
      toast.error('Failed to clear cart');
    } finally {
      setLoading(false);
    }
  };

  return (
    <CartContext.Provider
      value={{
        items,
        addItem,
        updateQuantity,
        removeItem,
        clearCart,
        loading,
        error,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
} 