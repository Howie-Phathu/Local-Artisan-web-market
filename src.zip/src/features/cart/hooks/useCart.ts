'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { useAuth } from '@/features/auth/hooks/useAuth';
import { toast } from 'sonner';

export interface CartItem {
  productId: string;
  productName: string;
  price: number;
  image: string;
  quantity: number;
  product?: {
    id: string;
    name: string;
    price: number;
    image: string;
    stock: number;
  };
}

interface Cart {
  items: CartItem[];
  total: number;
}

export function useCart() {
  const [cart, setCart] = useState<Cart>({ items: [], total: 0 });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      fetchCart();
    } else {
      setCart({ items: [], total: 0 });
    }
  }, [isAuthenticated]);

  const fetchCart = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await api.cart.get();
      setCart(response.data);
    } catch (error) {
      console.error('Error fetching cart:', error);
      setError('Failed to fetch cart');
      toast.error('Failed to fetch cart');
    } finally {
      setLoading(false);
    }
  };

  const addItem = async (productId: string, quantity: number) => {
    try {
      setLoading(true);
      setError(null);
      
      if (!isAuthenticated) {
        toast.error('Please log in to add items to cart');
        return;
      }

      const response = await api.cart.addItem({ productId, quantity });
      setCart(response.data);
      toast.success('Item added to cart');
    } catch (error: any) {
      console.error('Error adding item to cart:', error);
      setError('Failed to add item to cart');
      
      if (error.message.includes('stock')) {
        toast.error('Not enough stock available');
      } else {
        toast.error('Failed to add item to cart');
      }
    } finally {
      setLoading(false);
    }
  };

  const updateQuantity = async (productId: string, quantity: number) => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.cart.updateItem(productId, { quantity });
      setCart(response.data);
      toast.success('Cart updated');
    } catch (error: any) {
      console.error('Error updating cart:', error);
      setError('Failed to update cart');
      
      if (error.message.includes('stock')) {
        toast.error('Not enough stock available');
      } else {
        toast.error('Failed to update cart');
      }
    } finally {
      setLoading(false);
    }
  };

  const removeItem = async (productId: string) => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.cart.removeItem(productId);
      setCart(response.data);
      toast.success('Item removed from cart');
    } catch (error) {
      console.error('Error removing item from cart:', error);
      setError('Failed to remove item from cart');
      toast.error('Failed to remove item from cart');
    } finally {
      setLoading(false);
    }
  };

  const clearCart = async () => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.cart.clear();
      setCart(response.data);
      toast.success('Cart cleared');
    } catch (error) {
      console.error('Error clearing cart:', error);
      setError('Failed to clear cart');
      toast.error('Failed to clear cart');
    } finally {
      setLoading(false);
    }
  };

  return {
    cart,
    loading,
    error,
    addItem,
    updateQuantity,
    removeItem,
    clearCart,
    refresh: fetchCart,
    itemCount: cart.items.reduce((sum, item) => sum + item.quantity, 0),
    subtotal: cart.total
  };
} 