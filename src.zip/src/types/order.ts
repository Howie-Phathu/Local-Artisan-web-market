export interface Order {
  id: number;
  orderDate: Date;
  totalPrice: number;
  buyerId: number;
  paymentId: number;
  shipmentId: number;
}

export interface OrderItem {
  id: number;
  orderId: number;
  productId: number;
  quantity: number;
  itemPrice: number;
}

export interface Payment {
  id: number;
  orderId: number;
  paymentDate: Date;
  paymentMethod: string;
  amount: number;
}

export interface Shipment {
  id: number;
  shipmentDate: Date;
  address: string;
  carrier: string;
  status: string;
  buyerId: number;
} 