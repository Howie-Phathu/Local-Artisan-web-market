export interface Product {
  id: string;
  name: string;
  image: string;
  images: string[];
  description: string;
  price: number;
  stock: number;
  category: string;
  categoryId: string;
  shopId: string;
  createdAt: string;
  shop?: {
    id: string;
    name: string;
  };
}

export interface Category {
  id: string;
  name: string;
}

export interface Review {
  id: string;
  buyerId: string;
  productId: string;
  rating: number;
  comment: string;
  reviewDate: Date;
} 