export interface Shop {
  id: number;
  name: string;
  description: string;
  logo: string;
  banner: string;
  ownerId: number;
  rating: number;
  totalSales: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateShopData {
  name: string;
  description: string;
  logo?: File;
  banner?: File;
}

export interface UpdateShopData {
  name?: string;
  description?: string;
  logo?: File;
  banner?: File;
}

export interface Seller {
  id: number;
  name: string;
  email: string;
  contact: string;
} 