'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Users, Globe, Shield } from 'lucide-react';
import Image  from 'next/image';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold mb-6">About Artisan Marketplace</h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          We're on a mission to connect talented artisans with customers who appreciate
          handcrafted, unique products. Our platform celebrates craftsmanship and
          supports independent creators worldwide.
        </p>
      </div>

      {/* Our Story */}
      <section className="mb-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6">Our Story</h2>
            <p className="text-gray-600 mb-4">
              Artisan Marketplace was born from a simple idea: to create a space where
              talented craftspeople could share their work with the world. We believe
              in the power of handmade goods to tell stories, preserve traditions,
              and create meaningful connections.
            </p>
            <p className="text-gray-600">
              Since our founding, we've grown into a vibrant community of artisans
              and customers who share our passion for quality craftsmanship and
              sustainable practices.
            </p>
          </div>
          <div className="relative h-[400px] rounded-lg overflow-hidden">
            <Image
              src="https://crafty-clayworks.com/cdn/shop/articles/text-to-image_97361269-e456-4e21-9a8b-78cb3f1d23aa.png?v=1709866106"
              alt="Artisan at work"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader>
              <Heart className="h-8 w-8 text-red-500 mb-4" />
              <CardTitle>Quality Craftsmanship</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                We celebrate the skill and dedication that goes into every handmade item.
                Each product tells a story of tradition and innovation.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Users className="h-8 w-8 text-blue-500 mb-4" />
              <CardTitle>Community First</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                We're building a community where artisans and customers can connect,
                share stories, and support each other's creative journeys.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Globe className="h-8 w-8 text-green-500 mb-4" />
              <CardTitle>Sustainable Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                We promote sustainable and ethical production methods, helping to
                preserve traditional crafts while protecting our environment.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Shield className="h-8 w-8 text-purple-500 mb-4" />
              <CardTitle>Fair Trade</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                We ensure fair compensation for artisans and transparent pricing
                for customers, creating a marketplace built on trust and respect.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Call to Action */}
      <section className="text-center">
        <h2 className="text-3xl font-bold mb-6">Join Our Community</h2>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Whether you're an artisan looking to showcase your work or a customer
          seeking unique, handcrafted items, we welcome you to our community.
        </p>
        <div className="flex gap-4 justify-center">
          <Link href="/shops">
            <Button size="lg">Browse Shops</Button>
          </Link>
          <Link href="/contact">
            <Button size="lg" variant="outline">
              Contact Us
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
} 