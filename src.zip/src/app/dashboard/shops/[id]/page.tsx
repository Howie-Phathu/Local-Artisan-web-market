'use client';

import { useParams } from 'next/navigation';
import { useShops } from '@/features/shops/hooks/useShops';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Edit, Trash2, Plus, Package, Settings, BarChart } from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';

export default function ShopDetailsPage() {
  const { id } = useParams();
  const { shops, deleteShop, isLoading } = useShops();
  const shop = shops?.find((s) => s.id === id);

  const handleDelete = async () => {
    if (!shop) return;
    
    try {
      await deleteShop(shop.id);
      toast.success('Shop deleted successfully');
    } catch (error) {
      toast.error('Failed to delete shop');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Shop not found</h2>
        <p className="text-muted-foreground mb-4">
          The shop you're looking for doesn't exist or has been deleted.
        </p>
        <Button asChild>
          <Link href="/dashboard/shops">Back to Shops</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">{shop.name}</h1>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href={`/dashboard/shops/${shop.id}/edit`}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Shop
            </Link>
          </Button>
          <Button variant="destructive" onClick={handleDelete}>
            <Trash2 className="w-4 h-4 mr-2" />
            Delete Shop
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">
            <BarChart className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="products">
            <Package className="w-4 h-4 mr-2" />
            Products
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <Card className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Shop Information</h3>
                <div className="space-y-2">
                  <p><span className="font-medium">Name:</span> {shop.name}</p>
                  <p><span className="font-medium">Description:</span> {shop.description}</p>
                  <p><span className="font-medium">Created:</span> {new Date(shop.createdAt).toLocaleDateString()}</p>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-2">Statistics</h3>
                <div className="space-y-2">
                  <p><span className="font-medium">Total Products:</span> {shop.products?.length || 0}</p>
                  <p><span className="font-medium">Total Sales:</span> ${shop.totalSales?.toLocaleString() || 0}</p>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="products">
          <Card className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Products</h3>
              <Button asChild>
                <Link href={`/dashboard/shops/${shop.id}/products/new`}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Product
                </Link>
              </Button>
            </div>
            {shop.products && shop.products.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {shop.products.map((product) => (
                  <Card key={product.id} className="p-4">
                    <h4 className="font-medium">{product.name}</h4>
                    <p className="text-sm text-muted-foreground">${product.price}</p>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No products found</p>
                <Button asChild className="mt-4">
                  <Link href={`/dashboard/shops/${shop.id}/products/new`}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Product
                  </Link>
                </Button>
              </div>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Shop Settings</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Shop Status</h4>
                <p className="text-sm text-muted-foreground">
                  {shop.isActive ? 'Active' : 'Inactive'}
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2">Shop Type</h4>
                <p className="text-sm text-muted-foreground">
                  {shop.type || 'Standard'}
                </p>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
} 