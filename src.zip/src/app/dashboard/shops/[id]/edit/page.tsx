'use client';

import { useShops } from '@/features/shops/hooks/useShops';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ImageUpload } from '@/components/ui/image-upload';
import { ArrowLeft, Save } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';

export default function EditShopPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { shops, editShop } = useShops();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    logo: '',
    banner: '',
  });

  useEffect(() => {
    const shop = shops.find((s) => s.id === params.id);
    if (shop) {
      setFormData({
        name: shop.name,
        description: shop.description,
        logo: shop.logo,
        banner: shop.banner,
      });
    }
  }, [shops, params.id]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await editShop(params.id, formData);
      toast.success('Shop updated successfully');
      router.push('/dashboard/shops');
    } catch (error) {
      toast.error('Failed to update shop');
      console.error('Error updating shop:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleImageChange = (name: 'logo' | 'banner', value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center gap-4 mb-8">
        <Link href="/dashboard/shops">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Edit Shop</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Shop Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium">
                Shop Name
              </label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                placeholder="Enter your shop name"
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium">
                Description
              </label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                required
                placeholder="Tell us about your shop"
                className="min-h-[100px]"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Shop Logo</label>
              <ImageUpload
                value={formData.logo}
                onChange={(value) => handleImageChange('logo', value)}
                onRemove={() => handleImageChange('logo', '')}
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Shop Banner</label>
              <ImageUpload
                value={formData.banner}
                onChange={(value) => handleImageChange('banner', value)}
                onRemove={() => handleImageChange('banner', '')}
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={loading}>
                {loading ? (
                  'Saving...'
                ) : (
                  <>
                    <Save className="h-4 w-4 mr-2" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
} 