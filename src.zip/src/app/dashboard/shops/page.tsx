'use client';

import { useShops } from '@/features/shops/hooks/useShops';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Plus, Search, Trash2, Edit } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';
import { toast } from 'sonner';
import Image from 'next/image';

function ShopCardSkeleton() {
  return (
    <Card className="animate-pulse">
      <div className="h-48 bg-gray-200 rounded-t-lg" />
      <CardContent className="p-4">
        <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
        <div className="h-3 bg-gray-200 rounded w-1/2" />
      </CardContent>
    </Card>
  );
}

function ShopCard({ shop, onDelete }: { shop: any; onDelete: (id: string) => void }) {
  return (
    <Card>
      <div className="relative h-48">
        {shop.banner ? (
          <Image
            src={shop.banner}
            alt={shop.name}
            fill
            className="object-cover rounded-t-lg"
          />
        ) : (
          <div className="h-full bg-gray-100 rounded-t-lg flex items-center justify-center">
            <span className="text-gray-400">No banner</span>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="flex items-center gap-4 mb-4">
          {shop.logo ? (
            <Image
              src={shop.logo}
              alt={shop.name}
              width={48}
              height={48}
              className="rounded-full"
            />
          ) : (
            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
              <span className="text-gray-400">No logo</span>
            </div>
          )}
          <div>
            <h3 className="font-semibold">{shop.name}</h3>
            <p className="text-sm text-gray-500">{shop.products?.length || 0} products</p>
          </div>
        </div>
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{shop.description}</p>
        <div className="flex justify-end gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onDelete(shop.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
          <Link href={`/dashboard/shops/${shop.id}/edit`}>
            <Button variant="outline" size="sm">
              <Edit className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ShopsDashboard() {
  const { shops, loading, deleteShop } = useShops();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredShops = shops.filter((shop) =>
    shop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    shop.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this shop?')) {
      try {
        await deleteShop(id);
        toast.success('Shop deleted successfully');
      } catch (error) {
        toast.error('Failed to delete shop');
        console.error('Error deleting shop:', error);
      }
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">My Shops</h1>
        <Link href="/dashboard/shops/new">
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Create Shop
          </Button>
        </Link>
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search shops..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <ShopCardSkeleton key={i} />
          ))}
        </div>
      ) : filteredShops.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500 mb-4">No shops found</p>
          <Link href="/dashboard/shops/new">
            <Button>Create your first shop</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredShops.map((shop) => (
            <ShopCard
              key={shop.id}
              shop={shop}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}
    </div>
  );
} 