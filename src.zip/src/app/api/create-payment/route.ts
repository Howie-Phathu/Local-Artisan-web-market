import { NextResponse } from 'next/server';
import axios from 'axios';

const YOCO_SECRET_KEY = process.env.YOCO_SECRET_KEY!;
const YOCO_API_URL = 'https://online.yoco.com/v1/charges/';

export async function POST(request: Request) {
  try {
    const { amount } = await request.json();

    const response = await axios.post(
      YOCO_API_URL,
      {
        amount: amount * 100, // Convert to cents
        currency: 'ZAR',
        source: 'token', // This will be replaced with the actual token from the frontend
      },
      {
        headers: {
          'X-Auth-Secret-Key': YOCO_SECRET_KEY,
          'Content-Type': 'application/json',
        },
      }
    );

    return NextResponse.json({
      id: response.data.id,
      amount: amount,
      currency: 'ZAR',
      status: response.data.status,
    });
  } catch (error) {
    console.error('Error creating payment:', error);
    return NextResponse.json(
      { error: 'Error creating payment' },
      { status: 500 }
    );
  }
} 