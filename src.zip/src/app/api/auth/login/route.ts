import { NextResponse } from 'next/server';

// POST handler for login requests
export async function POST(request: Request) {
  try {
    // Extract email and password from request body
    const { email, password } = await request.json();

    // TODO: Replace with actual authentication logic
    // This is a mock implementation for testing
    // Check if credentials match the mock admin user
    if (email === 'admin@example.com' && password === 'admin123') {
      // Return mock user data for successful login
      return NextResponse.json({
        id: '1', // User ID
        name: 'Admin User', // User's full name
        email: 'admin@example.com', // User's email
        isAdmin: true, // Admin status
        isSeller: false, // Seller status
        isActive: true, // Account status
      });
    }

    // Return error response for invalid credentials
    return NextResponse.json(
      { error: 'Invalid credentials' },
      { status: 401 } // Unauthorized status code
    );
  } catch (error) {
    // Return error response for server errors
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 } // Server error status code
    );
  }
} 