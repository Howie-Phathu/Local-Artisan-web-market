import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json();

    // TODO: Replace with actual registration logic
    // This is a mock implementation
    return NextResponse.json({
      id: '1',
      name,
      email,
      isAdmin: false,
      isSeller: false,
      isActive: true,
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
} 