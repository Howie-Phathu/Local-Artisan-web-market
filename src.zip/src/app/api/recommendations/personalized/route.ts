import { NextResponse } from 'next/server';
import { api } from '@/lib/api';

export async function GET() {
  try {
    // Get user's purchase history and viewed products
    const [purchaseHistory, viewedProducts] = await Promise.all([
      api.orders.getUserOrders(),
      api.products.getRecentlyViewed(),
    ]);

    // Get all products
    const allProducts = await api.products.getAll();

    // Calculate product scores based on user behavior
    const productScores = new Map<string, number>();

    // Score products based on purchase history
    purchaseHistory.data.forEach((order: any) => {
      order.items.forEach((item: any) => {
        const score = productScores.get(item.productId) || 0;
        productScores.set(item.productId, score + 2); // Higher weight for purchases
      });
    });

    // Score products based on view history
    viewedProducts.data.forEach((product: any) => {
      const score = productScores.get(product.id) || 0;
      productScores.set(product.id, score + 1); // Lower weight for views
    });

    // Convert scores to recommendations
    const recommendations = allProducts.data
      .map((product: any) => ({
        ...product,
        similarity: productScores.get(product.id) || 0,
      }))
      .filter((product: any) => product.similarity > 0)
      .sort((a: any, b: any) => b.similarity - a.similarity)
      .slice(0, 10);

    return NextResponse.json(recommendations);
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return NextResponse.json(
      { error: 'Failed to generate recommendations' },
      { status: 500 }
    );
  }
} 