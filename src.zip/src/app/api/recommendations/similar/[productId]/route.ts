import { NextResponse } from 'next/server';
import { api } from '@/lib/api';

export async function GET(
  request: Request,
  { params }: { params: { productId: string } }
) {
  try {
    const { productId } = params;

    // Get the target product
    const targetProduct = await api.products.getById(productId);
    if (!targetProduct) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      );
    }

    // Get all products
    const allProducts = await api.products.getAll();

    // Calculate similarity scores
    const recommendations = allProducts.data
      .filter((product: any) => product.id !== productId)
      .map((product: any) => {
        // Calculate similarity based on category and price range
        let similarity = 0;

        // Same category gets a high score
        if (product.category === targetProduct.category) {
          similarity += 3;
        }

        // Similar price range gets a medium score
        const priceDiff = Math.abs(product.price - targetProduct.price);
        const priceRange = Math.max(targetProduct.price * 0.2, 100); // 20% of price or R100
        if (priceDiff <= priceRange) {
          similarity += 2;
        }

        // Similar name or description gets a low score
        const nameSimilarity = calculateTextSimilarity(
          product.name,
          targetProduct.name
        );
        const descSimilarity = calculateTextSimilarity(
          product.description,
          targetProduct.description
        );
        similarity += (nameSimilarity + descSimilarity) * 0.5;

        return {
          ...product,
          similarity,
        };
      })
      .sort((a: any, b: any) => b.similarity - a.similarity)
      .slice(0, 10);

    return NextResponse.json(recommendations);
  } catch (error) {
    console.error('Error generating similar products:', error);
    return NextResponse.json(
      { error: 'Failed to generate similar products' },
      { status: 500 }
    );
  }
}

// Simple text similarity function using Levenshtein distance
function calculateTextSimilarity(text1: string, text2: string): number {
  const words1 = text1.toLowerCase().split(/\s+/);
  const words2 = text2.toLowerCase().split(/\s+/);
  
  let commonWords = 0;
  words1.forEach(word1 => {
    if (words2.includes(word1)) {
      commonWords++;
    }
  });

  return commonWords / Math.max(words1.length, words2.length);
} 