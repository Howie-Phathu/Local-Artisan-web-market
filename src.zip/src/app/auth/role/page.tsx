'use client';

import { useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Store, User, Shield } from 'lucide-react';

export default function RoleSelectionPage() {
  const router = useRouter();

  const handleRoleSelect = (role: 'buyer' | 'seller' | 'admin') => {
    // Store the selected role in localStorage
    localStorage.setItem('selectedRole', role);
    // Redirect to the appropriate auth page
    router.push(`/auth/${role}`);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-center">Welcome to Artisan Marketplace</CardTitle>
            <CardDescription className="text-center">
              Please select your role to continue
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Buyer Card */}
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleRoleSelect('buyer')}>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <User className="h-12 w-12 text-blue-500" />
                    <h3 className="text-xl font-semibold">Buyer</h3>
                    <p className="text-sm text-gray-500">
                      Browse and purchase unique handcrafted products from our talented artisans
                    </p>
                    <Button variant="outline" className="w-full">
                      Continue as Buyer
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Seller Card */}
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleRoleSelect('seller')}>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <Store className="h-12 w-12 text-green-500" />
                    <h3 className="text-xl font-semibold">Seller</h3>
                    <p className="text-sm text-gray-500">
                      Showcase and sell your handcrafted products to customers worldwide
                    </p>
                    <Button variant="outline" className="w-full">
                      Continue as Seller
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Admin Card */}
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleRoleSelect('admin')}>
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center text-center space-y-4">
                    <Shield className="h-12 w-12 text-purple-500" />
                    <h3 className="text-xl font-semibold">Admin</h3>
                    <p className="text-sm text-gray-500">
                      Manage the marketplace, users, and ensure quality standards
                    </p>
                    <Button variant="outline" className="w-full">
                      Continue as Admin
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
} 