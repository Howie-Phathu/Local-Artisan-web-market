'use client';

import { useCart } from '@/features/cart/hooks/useCart';
import { Card } from '@/components/ui/card';
import { useState } from 'react';
import { formatCurrency } from '@/lib/utils/currency';
import type { CartItem } from '@/features/cart/hooks/useCart';
import { PaymentForm } from '@/components/payment/PaymentForm';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

export default function PaymentPage() {
  const router = useRouter();
  const { cart, subtotal, clearCart } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePaymentSuccess = async () => {
    try {
      setIsProcessing(true);
      // Here you would typically create an order in your backend
      await clearCart();
      toast.success('Payment successful! Your order has been placed.');
      router.push('/orders');
    } catch (error) {
      console.error('Error processing order:', error);
      toast.error('There was an error processing your order. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentError = (error: Error) => {
    toast.error(error.message || 'Payment failed. Please try again.');
  };

  if (cart.items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Your cart is empty</h2>
          <p className="mt-2 text-gray-600">
            Please add items to your cart before proceeding to checkout.
          </p>
          <button
            className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
            onClick={() => router.push('/products')}
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Checkout</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Order Summary */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
          <div className="space-y-4">
            {cart.items.map((item: CartItem) => (
              <div key={item.productId} className="flex justify-between items-center">
                <div className="flex items-center space-x-4">
                  {item.image && (
                    <img 
                      src={item.image} 
                      alt={item.productName} 
                      className="w-16 h-16 object-cover rounded"
                    />
                  )}
                  <div>
                    <p className="font-medium">{item.productName}</p>
                    <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                  </div>
                </div>
                <p className="font-medium">{formatCurrency(item.price * item.quantity)}</p>
              </div>
            ))}
            <div className="border-t pt-4 mt-4">
              <div className="flex justify-between font-bold">
                <p>Total</p>
                <p>{formatCurrency(subtotal)}</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Payment Form */}
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Payment Details</h2>
          <PaymentForm
            amount={subtotal}
            onSuccess={handlePaymentSuccess}
            onError={handlePaymentError}
          />
        </Card>
      </div>
    </div>
  );
} 