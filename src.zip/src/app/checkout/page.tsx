'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCart } from '@/features/cart/hooks/useCart';
import { PaymentForm } from '@/components/payment/PaymentForm';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, subtotal } = useCart();
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePaymentSuccess = async () => {
    try {
      setIsProcessing(true);
      // Here you would typically create an order in your backend
      // and clear the cart
      toast.success('Payment successful! Your order has been placed.');
      router.push('/orders');
    } catch (error) {
      console.error('Error processing order:', error);
      toast.error('There was an error processing your order. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentError = (error: Error) => {
    toast.error(error.message || 'Payment failed. Please try again.');
  };

  if (cart.items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900">Your cart is empty</h2>
            <p className="mt-2 text-gray-600">
              Please add items to your cart before proceeding to checkout.
            </p>
            <Button
              className="mt-4"
              onClick={() => router.push('/products')}
            >
              Continue Shopping
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Summary */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
            <div className="space-y-4">
              {cart.items.map((item) => (
                <div key={item.productId} className="flex justify-between">
                  <span>
                    {item.product?.name || 'Product'} x {item.quantity}
                  </span>
                  <span>R{(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t pt-4">
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>R{subtotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </Card>

          {/* Payment Section */}
          <Card className="p-6">
            <h2 className="text-xl font-semibold mb-4">Payment</h2>
            <PaymentForm
              amount={subtotal}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          </Card>
        </div>
      </div>
    </div>
  );
} 