'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ImageUpload } from '@/components/ui/image-upload';
import { toast } from 'sonner';
import { api } from '@/lib/api';

// Form validation schema
const shopSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  logo: z.string().optional(),
  banner: z.string().optional(),
});

type ShopFormData = z.infer<typeof shopSchema>;

export default function NewShopPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [images, setImages] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ShopFormData>({
    resolver: zodResolver(shopSchema),
  });

  const onSubmit = async (data: ShopFormData) => {
    try {
      setLoading(true);

      // Create the shop with the uploaded images
      const response = await api.shops.create({
        ...data,
        logo: images[0] || null,
        banner: images[1] || null,
      });

      toast.success('Shop created successfully!');
      router.push(`/seller/shops/${response.data.id}`);
    } catch (error) {
      console.error('Error creating shop:', error);
      toast.error('Failed to create shop. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Create New Shop</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="max-w-2xl space-y-6">
        {/* Shop Name */}
        <div>
          <label htmlFor="name" className="block text-sm font-medium mb-2">
            Shop Name
          </label>
          <Input
            id="name"
            {...register('name')}
            placeholder="Enter your shop name"
          />
          {errors.name && (
            <p className="text-red-500 text-sm mt-1">{errors.name.message}</p>
          )}
        </div>

        {/* Shop Description */}
        <div>
          <label htmlFor="description" className="block text-sm font-medium mb-2">
            Description
          </label>
          <Textarea
            id="description"
            {...register('description')}
            placeholder="Describe your shop"
            rows={4}
          />
          {errors.description && (
            <p className="text-red-500 text-sm mt-1">{errors.description.message}</p>
          )}
        </div>

        {/* Shop Images */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Shop Images
          </label>
          <p className="text-sm text-gray-500 mb-4">
            Upload a logo and banner image for your shop. The first image will be used as the logo,
            and the second as the banner.
          </p>
          <ImageUpload
            value={images}
            onChange={setImages}
            maxFiles={2}
          />
        </div>

        {/* Submit Button */}
        <Button type="submit" disabled={loading}>
          {loading ? 'Creating...' : 'Create Shop'}
        </Button>
      </form>
    </div>
  );
} 