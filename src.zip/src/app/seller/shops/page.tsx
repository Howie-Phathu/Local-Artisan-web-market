'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Plus } from 'lucide-react';
import { ImageUpload } from '@/components/ui/image-upload';

interface Shop {
  id: string;
  name: string;
  description: string;
  address: string;
  phone: string;
  logo: string;
}

export default function ShopManagement() {
  const [shops, setShops] = useState<Shop[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newShop, setNewShop] = useState<Omit<Shop, 'id'>>({
    name: '',
    description: '',
    address: '',
    phone: '',
    logo: '',
  });

  const handleCreateShop = () => {
    // TODO: Implement shop creation logic
    setShops([...shops, { ...newShop, id: Date.now().toString() }]);
    setNewShop({ 
      name: '', 
      description: '', 
      address: '', 
      phone: '',
      logo: '',
    });
    setIsCreating(false);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Shop Management</h1>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Create New Shop
        </Button>
      </div>

      {/* Create Shop Form */}
      {isCreating && (
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Create New Shop</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Shop Name</Label>
                <Input
                  id="name"
                  value={newShop.name}
                  onChange={(e) => setNewShop({ ...newShop, name: e.target.value })}
                  placeholder="Enter shop name"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newShop.description}
                  onChange={(e) => setNewShop({ ...newShop, description: e.target.value })}
                  placeholder="Enter shop description"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="address">Address</Label>
                <Input
                  id="address"
                  value={newShop.address}
                  onChange={(e) => setNewShop({ ...newShop, address: e.target.value })}
                  placeholder="Enter shop address"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={newShop.phone}
                  onChange={(e) => setNewShop({ ...newShop, phone: e.target.value })}
                  placeholder="Enter phone number"
                />
              </div>
              <div className="grid gap-2">
                <Label>Shop Logo</Label>
                <ImageUpload
                  value={newShop.logo}
                  onChange={(value) => setNewShop({ ...newShop, logo: value })}
                  onRemove={() => setNewShop({ ...newShop, logo: '' })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsCreating(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateShop}>Create Shop</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Shop List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {shops.map((shop) => (
          <Card key={shop.id}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4">
                {shop.logo && (
                  <div className="relative w-16 h-16 rounded-full overflow-hidden">
                    <img
                      src={shop.logo}
                      alt={shop.name}
                      className="object-cover w-full h-full"
                    />
                  </div>
                )}
                <div>
                  <h3 className="font-semibold">{shop.name}</h3>
                  <p className="text-sm text-gray-500">{shop.address}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
} 