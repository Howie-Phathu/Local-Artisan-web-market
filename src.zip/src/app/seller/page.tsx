'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function SellerPage() {
  const router = useRouter();

  useEffect(() => {
    router.push('/seller/dashboard');
  }, [router]);

  return null;
} 