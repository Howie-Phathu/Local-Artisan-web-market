'use client';

import { useCart } from '@/features/cart/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Minus, Plus, ShoppingCart, Trash } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { toast } from 'sonner';
import { useAuth } from '@/features/auth/hooks/useAuth';
import type { CartItem as CartItemType } from '@/features/cart/hooks/useCart';

function CartItem({ item }: { item: CartItemType }) {
  const { updateQuantity, removeItem } = useCart();

  return (
    <div className="flex items-center gap-4 py-4 border-b">
      <div className="relative w-20 h-20">
        <img
          src={item.image}
          alt={item.productName}
          className="object-cover rounded-md"
        />
      </div>
      <div className="flex-grow">
        <h3 className="font-medium">{item.productName}</h3>
        <p className="text-sm text-gray-500">${item.price.toFixed(2)}</p>
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="icon"
          onClick={() => updateQuantity(item.productId, item.quantity - 1)}
          disabled={item.quantity <= 1}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <Input
          type="number"
          value={item.quantity}
          onChange={(e) => updateQuantity(item.productId, parseInt(e.target.value))}
          className="w-16 text-center"
          min={1}
          max={item.product?.stock}
        />
        <Button
          variant="outline"
          size="icon"
          onClick={() => updateQuantity(item.productId, item.quantity + 1)}
          disabled={item.product && item.quantity >= item.product.stock}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="w-24 text-right">
        <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => {
          removeItem(item.productId);
          toast.success('Item removed from cart');
        }}
      >
        <Trash className="h-4 w-4" />
      </Button>
    </div>
  );
}

export default function CartPage() {
  const { cart, clearCart, itemCount, subtotal } = useCart();
  const router = useRouter();
  const { isAuthenticated, login } = useAuth();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const handleCheckout = async () => {
    if (!isAuthenticated) {
      setIsCheckingOut(true);
      try {
        await login();
        router.push('/checkout');
      } catch (error) {
        toast.error('Please login to continue with checkout');
      } finally {
        setIsCheckingOut(false);
      }
    } else {
      router.push('/checkout');
    }
  };

  if (cart.items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <ShoppingCart className="mx-auto h-12 w-12 text-gray-400" />
            <h2 className="mt-2 text-lg font-medium text-gray-900">Your cart is empty</h2>
            <p className="mt-1 text-sm text-gray-500">
              Start shopping to add items to your cart
            </p>
            <div className="mt-6">
              <Button onClick={() => router.push('/products')}>
                Continue Shopping
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-8">Shopping Cart</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card>
              <div className="p-6">
                {cart.items.map((item) => (
                  <CartItem key={item.productId} item={item} />
                ))}
              </div>
            </Card>
            <div className="mt-4">
              <Button
                variant="outline"
                onClick={() => {
                  clearCart();
                  toast.success('Cart cleared');
                }}
              >
                Clear Cart
              </Button>
            </div>
          </div>
          <div>
            <Card>
              <div className="p-6">
                <h2 className="text-lg font-medium mb-4">Order Summary</h2>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal ({itemCount} items)</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>Calculated at checkout</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
                <Button
                  className="w-full mt-6"
                  onClick={handleCheckout}
                  disabled={isCheckingOut}
                >
                  {isCheckingOut ? 'Processing...' : 'Proceed to Checkout'}
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
} 