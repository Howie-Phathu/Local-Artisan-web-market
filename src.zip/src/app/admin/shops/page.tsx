'use client';

import { useShops } from '@/features/shops/hooks/useShops';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Edit, Search, Store, Trash2 } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { toast } from 'sonner';
import { Skeleton } from '@/components/ui/skeleton';
import Image from 'next/image';

function ShopCard({ shop }: { shop: any }) {
  const router = useRouter();
  const { deleteShop } = useShops();

  const handleDelete = async () => {
    if (confirm('Are you sure you want to delete this shop?')) {
      try {
        await deleteShop(shop.id);
        toast.success('Shop deleted successfully');
      } catch (error) {
        toast.error('Failed to delete shop');
        console.error('Error deleting shop:', error);
      }
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-40 w-full">
        <Image
          src={shop.banner}
          alt={shop.name}
          fill
          className="object-cover"
        />
      </div>
      <CardContent className="p-4">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
            <Image
              src={shop.logo}
              alt={shop.name}
              width={48}
              height={48}
              className="object-cover"
            />
          </div>
          <div>
            <h3 className="font-semibold">{shop.name}</h3>
            <p className="text-sm text-gray-600">{shop.products?.length || 0} products</p>
          </div>
        </div>
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{shop.description}</p>
        <div className="flex justify-end gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => router.push(`/admin/shops/${shop.id}/edit`)}
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <Button
            variant="destructive"
            size="sm"
            onClick={handleDelete}
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function ShopCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <Skeleton className="h-40 w-full" />
      <CardContent className="p-4">
        <div className="flex items-center gap-4 mb-4">
          <Skeleton className="w-12 h-12 rounded-full" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-24" />
          </div>
        </div>
        <Skeleton className="h-4 w-full mb-4" />
        <Skeleton className="h-4 w-3/4 mb-4" />
        <div className="flex justify-end gap-2">
          <Skeleton className="h-8 w-20" />
          <Skeleton className="h-8 w-20" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function ShopsPage() {
  const { shops, loading } = useShops();
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Shops</h1>
        <Link href="/admin/shops/new">
          <Button>
            <Store className="h-4 w-4 mr-2" />
            Add Shop
          </Button>
        </Link>
      </div>

      <div className="mb-6">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search shops..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <ShopCardSkeleton key={i} />
          ))}
        </div>
      ) : shops.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-50 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <Store className="w-12 h-12 text-gray-400" />
          </div>
          <h2 className="text-xl font-semibold mb-2">No Shops Yet</h2>
          <p className="text-gray-600 mb-6">
            Add your first shop to get started
          </p>
          <Link href="/admin/shops/new">
            <Button>Add Shop</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {shops
            .filter(shop =>
              shop.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
              shop.description.toLowerCase().includes(searchQuery.toLowerCase())
            )
            .map((shop) => (
              <ShopCard key={shop.id} shop={shop} />
            ))}
        </div>
      )}
    </div>
  );
} 