'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Users, Store, Package, DollarSign } from 'lucide-react';
import { api } from '@/lib/api';

// Define the Product type
interface Product {
  id: string;
  totalSales: number;
  [key: string]: any; // Allow other properties
}

interface StatCardProps {
  title: string;
  value: number;
  icon: React.ReactNode;
  link: string;
  loading?: boolean;
}

function StatCard({ title, value, icon, link, loading = false }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        {loading ? (
          <Skeleton className="h-8 w-24" />
        ) : (
          <div className="text-2xl font-bold">{value.toLocaleString()}</div>
        )}
      </CardContent>
    </Card>
  );
}

export default function AdminDashboard() {
  const router = useRouter();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalShops: 0,
    totalProducts: 0,
    totalSales: 0
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch all necessary data
        const [usersResponse, shopsResponse, productsResponse] = await Promise.all([
          api.users.getAll(),
          api.shops.getAll(),
          api.products.getAll()
        ]);

        // Extract data from responses
        const users = usersResponse.data || [];
        const shops = shopsResponse.data || [];
        const products = productsResponse.data || [];

        // Calculate totals
        const totalUsers = users.length;
        const totalShops = shops.length;
        const totalProducts = products.length;
        const totalSales = products.reduce((sum: number, product: Product) => {
          const sales = product?.totalSales || 0;
          return sum + sales;
        }, 0);

        setStats({
          totalUsers,
          totalShops,
          totalProducts,
          totalSales
        });
      } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        setError('Failed to load dashboard statistics');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px]">
        <p className="text-red-500 mb-4">{error}</p>
        <Button onClick={() => window.location.reload()}>Retry</Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="space-x-4">
          <Button onClick={() => router.push('/admin/users/new')}>
            Add User
          </Button>
          <Button onClick={() => router.push('/admin/shops/new')}>
            Add Shop
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Users"
          value={stats.totalUsers}
          icon={<Users className="h-4 w-4 text-muted-foreground" />}
          link="/admin/users"
          loading={loading}
        />
        <StatCard
          title="Total Shops"
          value={stats.totalShops}
          icon={<Store className="h-4 w-4 text-muted-foreground" />}
          link="/admin/shops"
          loading={loading}
        />
        <StatCard
          title="Total Products"
          value={stats.totalProducts}
          icon={<Package className="h-4 w-4 text-muted-foreground" />}
          link="/admin/products"
          loading={loading}
        />
        <StatCard
          title="Total Sales"
          value={stats.totalSales}
          icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
          link="/admin/sales"
          loading={loading}
        />
      </div>
    </div>
  );
} 