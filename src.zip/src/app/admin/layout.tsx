'use client';

import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Users, ShoppingBag, Store, Settings, LogOut } from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

const adminNavItems = [
  {
    title: 'Dashboard',
    href: '/admin',
    icon: Settings,
  },
  {
    title: 'Users',
    href: '/admin/users',
    icon: Users,
  },
  {
    title: 'Shops',
    href: '/admin/shops',
    icon: Store,
  },
  {
    title: 'Products',
    href: '/admin/products',
    icon: ShoppingBag,
  },
];

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex h-screen">
        {/* Sidebar */}
        <div className="w-64 bg-white border-r">
          <div className="p-4 border-b">
            <h1 className="text-xl font-bold">Admin Dashboard</h1>
          </div>
          <nav className="p-4 space-y-2">
            {adminNavItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link key={item.href} href={item.href}>
                  <Button
                    variant={isActive ? 'secondary' : 'ghost'}
                    className="w-full justify-start"
                  >
                    <item.icon className="h-4 w-4 mr-2" />
                    {item.title}
                  </Button>
                </Link>
              );
            })}
          </nav>
          <div className="p-4 border-t mt-auto">
            <Link href="/">
              <Button
                variant="ghost"
                className="w-full justify-start text-red-600 hover:text-red-700"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-auto">
          <div className="p-8">{children}</div>
        </div>
      </div>
    </div>
  );
} 