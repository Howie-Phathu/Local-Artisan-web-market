import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Products - Artisan',
  description: 'Browse our collection of handcrafted products from independent artisans.',
};

export default function ProductsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <>{children}</>;
} 