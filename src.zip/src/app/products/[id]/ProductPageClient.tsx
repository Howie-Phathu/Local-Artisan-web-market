'use client';

import { useProducts } from '@/features/products/hooks/useProducts';
import { useCart } from '@/features/cart/hooks/useCart';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Star, ShoppingBag, Heart, Share2, ChevronLeft } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { toast } from 'sonner';
import { ProductRecommendations } from '@/components/products/ProductRecommendations';

interface ProductPageClientProps {
  id: string;
}

export default function ProductPageClient({ id }: ProductPageClientProps) {
  const router = useRouter();
  const { products, loading, error, getProduct } = useProducts();
  const { addItem } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const product = getProduct(id);

  if (loading) {
    return null; // Loading is handled by Suspense
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-red-600">{error}</p>
          <Button onClick={() => router.refresh()} className="mt-4">
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <p className="text-gray-600">Product not found</p>
          <Button onClick={() => router.back()} className="mt-4">
            Go Back
          </Button>
        </div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity,
    });
    toast.success('Added to cart');
  };

  const images = [product.image, ...(product.images || [])];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="mb-8"
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Back
        </Button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative aspect-square rounded-lg overflow-hidden">
              <Image
                src={images[selectedImage]}
                alt={product.name}
                fill
                className="object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`relative aspect-square rounded-lg overflow-hidden border-2 ${
                    selectedImage === index
                      ? 'border-primary'
                      : 'border-transparent'
                  }`}
                >
                  <Image
                    src={image}
                    alt={`${product.name} - Image ${index + 1}`}
                    fill
                    className="object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex items-center text-yellow-400">
                  <Star className="w-5 h-5 fill-current" />
                  <span className="ml-1 text-gray-700">
                    {product.rating?.toFixed(1) || 'New'}
                  </span>
                </div>
                <span className="text-gray-500">•</span>
                <span className="text-gray-500">{product.reviews || 0} reviews</span>
              </div>
            </div>

            <div className="text-2xl font-bold">${product.price.toFixed(2)}</div>

            <p className="text-gray-600">{product.description}</p>

            {product.details && product.details.length > 0 && (
              <div className="space-y-2">
                <h3 className="font-semibold">Details</h3>
                <ul className="list-disc list-inside text-gray-600">
                  {product.details.map((detail: string, index: number) => (
                    <li key={index}>{detail}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="flex items-center gap-4">
              <div className="flex items-center border rounded-md">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                >
                  -
                </Button>
                <span className="w-12 text-center">{quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setQuantity((q) => q + 1)}
                >
                  +
                </Button>
              </div>
              <Button
                size="lg"
                className="flex-1"
                onClick={handleAddToCart}
              >
                <ShoppingBag className="h-4 w-4 mr-2" />
                Add to Cart
              </Button>
            </div>

            <div className="flex gap-4">
              <Button variant="outline" size="icon">
                <Heart className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-4 w-4" />
              </Button>
            </div>

            {/* Shop Info */}
            {product.shop && (
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    {product.shop.logo && (
                      <div className="relative w-12 h-12 rounded-full overflow-hidden">
                        <Image
                          src={product.shop.logo}
                          alt={product.shop.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                    )}
                    <div>
                      <Link
                        href={`/shops/${product.shop.id}`}
                        className="font-semibold hover:text-primary"
                      >
                        {product.shop.name}
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Similar Products */}
        <div className="mt-12">
          <ProductRecommendations
            productId={id}
            title="Similar Products You May Like"
            limit={4}
          />
        </div>
      </div>
    </div>
  );
} 