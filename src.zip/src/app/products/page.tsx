'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { ProductFilters } from '@/components/products/ProductFilters';
import ProductCard from '@/components/products/ProductCard';
import { api } from '@/lib/api';
import { Skeleton } from '@/components/ui/skeleton';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  images: string[];
  image: string; // Main product image
  category: string;
  categoryId: string;
  stock: number;
  shopId: string;
  createdAt: string;
  shop: {
    id: string;
    name: string;
  };
}

interface Category {
  id: string;
  name: string;
}

interface FilterState {
  search: string;
  category: string;
  minPrice: number;
  maxPrice: number;
  sortBy: string;
}

export default function ProductsPage() {
  const searchParams = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch products with filters
  const fetchProducts = async (filters: FilterState) => {
    try {
      setLoading(true);
      setError(null);

      const response = await api.products.getAll();
      let filteredProducts = response.data || [];

      // Apply filters
      if (filters.search) {
        filteredProducts = filteredProducts.filter((product: Product) =>
          product.name.toLowerCase().includes(filters.search.toLowerCase()) ||
          product.description.toLowerCase().includes(filters.search.toLowerCase())
        );
      }

      if (filters.category) {
        filteredProducts = filteredProducts.filter((product: Product) =>
          product.category === filters.category
        );
      }

      if (filters.minPrice > 0 || filters.maxPrice < 1000) {
        filteredProducts = filteredProducts.filter((product: Product) =>
          product.price >= filters.minPrice && product.price <= filters.maxPrice
        );
      }

      // Apply sorting
      switch (filters.sortBy) {
        case 'price_asc':
          filteredProducts.sort((a: Product, b: Product) => a.price - b.price);
          break;
        case 'price_desc':
          filteredProducts.sort((a: Product, b: Product) => b.price - a.price);
          break;
        case 'name_asc':
          filteredProducts.sort((a: Product, b: Product) => a.name.localeCompare(b.name));
          break;
        case 'name_desc':
          filteredProducts.sort((a: Product, b: Product) => b.name.localeCompare(a.name));
          break;
        default: // 'newest'
          filteredProducts.sort((a: Product, b: Product) => 
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
          );
      }

      setProducts(filteredProducts);
    } catch (error) {
      console.error('Error fetching products:', error);
      setError('Failed to load products. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  // Fetch categories
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        // Since we don't have a categories API endpoint yet, we'll use mock data
        const mockCategories: Category[] = [
          { id: '1', name: 'Handmade Crafts' },
          { id: '2', name: 'Art Supplies' },
          { id: '3', name: 'Home Decor' },
          { id: '4', name: 'Jewelry' },
        ];
        setCategories(mockCategories);
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    fetchCategories();
  }, []);

  // Handle filter changes
  const handleFilterChange = (filters: FilterState) => {
    fetchProducts(filters);
  };

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Products</h1>

      {/* Filters */}
      <div className="mb-8">
        <ProductFilters
          categories={categories}
          onFilterChange={handleFilterChange}
        />
      </div>

      {/* Products Grid */}
      {error ? (
        <div className="text-center py-8">
          <p className="text-red-600">{error}</p>
        </div>
      ) : loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <Skeleton className="aspect-w-3 aspect-h-2" />
              <div className="p-4 space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-8 w-1/4" />
              </div>
            </div>
          ))}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-gray-500">No products found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              showShop={true}
            />
          ))}
        </div>
      )}
    </div>
  );
} 