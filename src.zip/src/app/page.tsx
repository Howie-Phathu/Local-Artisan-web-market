'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useFeaturedProducts } from '@/features/products/hooks/useFeaturedProducts';
import ProductCard from '@/components/products/ProductCard';
import { ShoppingCart, LogIn } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function Home() {
  const { featuredProducts, categories, loading, error } = useFeaturedProducts();
  const router = useRouter();

  return (
    <div>
      {/* Hero Section - Main banner at the top of the page */}
      <div className="relative h-[600px] w-full">
        {/* Hero background image */}
        <Image
          src="https://crafty-clayworks.com/cdn/shop/articles/text-to-image_97361269-e456-4e21-9a8b-78cb3f1d23aa.png?v=1709866106"
          alt="Artisan Marketplace Hero"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-center text-white max-w-2xl px-4">
            <h1 className="text-5xl font-bold mb-6">Discover Handcrafted Treasures</h1>
            <p className="text-xl mb-8">
              Explore unique, handmade products from talented artisans around the world.
              Support local craftsmanship and find one-of-a-kind pieces for your home and life.
            </p>
            <div className="flex gap-4 justify-center">
              <Link href="/shops">
                <Button size="lg" className="bg-white text-black hover:bg-gray-100">
                  Browse Shops
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Products */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Button 
              variant="outline"
              onClick={() => router.push('/products')}
            >
              View All Products
            </Button>
          </div>
          {error ? (
            <div className="text-center py-8">
              <p className="text-red-600">{error}</p>
            </div>
          ) : loading ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Loading featured products...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts.map(product => (
                <ProductCard
                  key={product.id}
                  product={product}
                  showShop={true}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Shop by Category</h2>
            <Button 
              variant="outline"
              onClick={() => router.push('/categories')}
            >
              All Categories
            </Button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {categories.map(category => (
              <Button
                key={category.id}
                variant="outline"
                className="h-32 flex flex-col items-center justify-center p-6 rounded-lg hover:bg-gray-100 transition-colors"
                onClick={() => router.push(`/products?category=${category.id}`)}
              >
                <h3 className="text-lg font-semibold">{category.name}</h3>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-12 text-center">Why Choose Artisan</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Unique Products</h3>
              <p className="text-gray-600 mb-4">
                Discover one-of-a-kind items that you won't find anywhere else.
              </p>
              <Button 
                variant="link"
                onClick={() => router.push('/products?featured=true')}
              >
                Shop Unique Items
              </Button>
            </div>
            <div className="text-center">
              <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Shipping</h3>
              <p className="text-gray-600 mb-4">
                Get your items delivered quickly and safely to your doorstep.
              </p>
              <Button 
                variant="link"
                onClick={() => router.push('/shipping')}
              >
                Learn About Shipping
              </Button>
            </div>
            <div className="text-center">
              <div className="bg-indigo-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-2">Secure Shopping</h3>
              <p className="text-gray-600 mb-4">
                Shop with confidence knowing your information is protected.
              </p>
              <Button 
                variant="link"
                onClick={() => router.push('/security')}
              >
                Our Security Promise
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
